#!/bin/bash

./clean.sh
./retreive_websites.sh $1
